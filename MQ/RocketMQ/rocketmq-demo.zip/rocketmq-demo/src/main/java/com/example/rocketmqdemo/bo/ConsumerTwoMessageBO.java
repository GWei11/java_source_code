package com.example.rocketmqdemo.bo;

import lombok.Data;

/**
 * @className ConsumerOneMessageBO.java
 * @description //TODO
 * @version 1.0
 */
@Data
public class ConsumerTwoMessageBO {
    private int twoAge;
    private String twoName;
}