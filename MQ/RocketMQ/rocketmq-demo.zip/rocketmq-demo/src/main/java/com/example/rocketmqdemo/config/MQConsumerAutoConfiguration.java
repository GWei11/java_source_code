package com.example.rocketmqdemo.config;

import com.example.rocketmqdemo.anno.MQConsumer;
import com.example.rocketmqdemo.interace.AbstractMQPushConsumer;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * @version 1.0
 * @className MQConsumerAutoConfiguration.java
 * @description
 */
@Configuration
@EnableConfigurationProperties({MQProperties.class})
public class MQConsumerAutoConfiguration implements ApplicationContextAware {
    // 保存配置信息
    protected MQProperties mqProperties;
    // 保存已经注册过的消费者组
    private Map<String, String> validConsumerMap;
    protected ConfigurableApplicationContext applicationContext;

    @Autowired
    public void setMqProperties(MQProperties mqProperties) {
        this.mqProperties = mqProperties;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.applicationContext = (ConfigurableApplicationContext) applicationContext;
    }

    @PostConstruct
    public void init() throws Exception {
        Map<String, Object> beans = this.applicationContext.getBeansWithAnnotation(MQConsumer.class);
        this.validConsumerMap = new HashMap();
        Iterator var2 = beans.entrySet().iterator();
        while (var2.hasNext()) {
            Map.Entry<String, Object> entry = (Map.Entry) var2.next();
            this.publishConsumer((String) entry.getKey(), entry.getValue());
        }
        this.validConsumerMap = null;
    }

    private void publishConsumer(String beanName, Object bean) throws Exception {
        MQConsumer mqConsumer = (MQConsumer) this.applicationContext.findAnnotationOnBean(beanName, MQConsumer.class);
        if (StringUtils.isEmpty(this.mqProperties.getNamesrvAddr())) {
            throw new RuntimeException("name server address 不能为空");
        } else {
            Environment environment = this.applicationContext.getEnvironment();
            String consumerGroup = environment.resolvePlaceholders(mqConsumer.consumerGroup());
            String topic = environment.resolvePlaceholders(mqConsumer.topic());
            String tags = "*";
            if (mqConsumer.tag().length == 1) {
                tags = environment.resolvePlaceholders(mqConsumer.tag()[0]);
            }

            if (!StringUtils.isEmpty((CharSequence) this.validConsumerMap.get(consumerGroup))) {
                String exist = (String) this.validConsumerMap.get(consumerGroup);
                throw new RuntimeException("消费组重复订阅，请新增消费组用于新的topic和tag组合: " + consumerGroup + "已经订阅了" + exist);
            } else {
                this.validConsumerMap.put(consumerGroup, topic + "-" + tags);
                if (AbstractMQPushConsumer.class.isAssignableFrom(bean.getClass())) {
                    DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(consumerGroup, true);
                    consumer.setNamesrvAddr(this.mqProperties.getNamesrvAddr());
                    consumer.subscribe(topic, tags);
                    consumer.setInstanceName(UUID.randomUUID().toString());
                    AbstractMQPushConsumer abstractMQPushConsumer = (AbstractMQPushConsumer) bean;
                    consumer.registerMessageListener(abstractMQPushConsumer::dealMessage);
                    abstractMQPushConsumer.setConsumer(consumer);
                    consumer.start();
                }
            }
        }
    }
}