package com.example.rocketmqdemo.config;

import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @version 1.0
 * @className MQProducerConfiguration.java
 * @description //TODO
 */
@Configuration
@EnableConfigurationProperties({MQProperties.class})
public class MQProducerConfiguration {
    protected MQProperties mqProperties;

    @Bean
    public DefaultMQProducer producer() throws MQClientException {
        DefaultMQProducer producer = new DefaultMQProducer(this.mqProperties.getProducerGroupName(), true);
        producer.setNamesrvAddr(this.mqProperties.getNamesrvAddr());
        producer.setSendMsgTimeout(this.mqProperties.getSendMsgTimeout());
        producer.setVipChannelEnabled(this.mqProperties.isVipChannelEnabled());
        producer.start();
        return producer;
    }

    @Autowired
    public void setMqProperties(MQProperties mqProperties) {
        this.mqProperties = mqProperties;
    }

    public MQProperties getMqProperties() {
        return mqProperties;
    }
}