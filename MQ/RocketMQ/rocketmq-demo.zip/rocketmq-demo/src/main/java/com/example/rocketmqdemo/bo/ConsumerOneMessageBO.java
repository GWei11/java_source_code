package com.example.rocketmqdemo.bo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @className ConsumerOneMessageBO.java
 * @description //TODO
 * @version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumerOneMessageBO {
    private int oneAge;
    private String oneName;
}