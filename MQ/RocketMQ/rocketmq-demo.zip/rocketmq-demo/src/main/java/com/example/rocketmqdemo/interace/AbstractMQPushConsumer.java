package com.example.rocketmqdemo.interace;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.common.message.MessageExt;
import org.springframework.util.Assert;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @version 1.0
 * @className AbstractMQPushConsumer.java
 * @description //TODO
 */
public abstract class AbstractMQPushConsumer<T> {

    private DefaultMQPushConsumer consumer;

    public abstract boolean process(T var1, Map<String, Object> var2);

    protected T parseMessage(MessageExt messageExt) {
        if (messageExt != null && messageExt.getBody() != null) {
            Type type = this.getMessageType();
            if (type instanceof Class) {
                try {
                    return JSONObject.parseObject(new String(messageExt.getBody()), type, new Feature[0]);
                } catch (Exception var4) {
                    //log.error("msgId: {}, tags: {}, keys: {}, parse message json fail", new Object[]{messageExt.getMsgId(), messageExt.getTags(), messageExt.getKeys(), var4});
                }
            } else {
                //log.warn("Parse msg error. msg:{}, msgId:{}, tags: {}, keys: {},", new Object[]{messageExt, messageExt.getMsgId(), messageExt.getTags(), messageExt.getKeys()});
            }
            return null;
        } else {
            return null;
        }
    }

    protected Map<String, Object> parseExtParam(MessageExt message) {
        Map<String, Object> extMap = new HashMap();
        extMap.put("TOPIC", message.getTopic());
        extMap.put("TEST", "测试参数");
        return extMap;
    }

    protected Type getMessageType() {
        Type superType = this.getClass().getGenericSuperclass();
        if (superType instanceof ParameterizedType) {
            ParameterizedType parameterizedType = (ParameterizedType) superType;
            Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
            Assert.isTrue(actualTypeArguments.length == 1, "Number of type arguments must be 1");
            return actualTypeArguments[0];
        } else {
            return Object.class;
        }
    }

    public ConsumeConcurrentlyStatus dealMessage(List<MessageExt> list, ConsumeConcurrentlyContext consumeConcurrentlyContext) {
        Iterator var3 = list.iterator();
        MessageExt messageExt;
        T t;
        Map ext;
        do {
            if (!var3.hasNext()) {
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            }
            messageExt = (MessageExt) var3.next();
            t = this.parseMessage(messageExt);
            ext = this.parseExtParam(messageExt);
        } while (t == null || this.process(t, ext));

        return ConsumeConcurrentlyStatus.RECONSUME_LATER;
    }

    public DefaultMQPushConsumer getConsumer() {
        return this.consumer;
    }

    public void setConsumer(DefaultMQPushConsumer consumer) {
        this.consumer = consumer;
    }
}