package com.example.rocketmqdemo.producer;

import com.alibaba.fastjson.JSONObject;
import com.example.rocketmqdemo.bo.ConsumerOneMessageBO;
import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.remoting.common.RemotingHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @version 1.0
 * @className ProducerOne.java
 * @description //TODO
 */
@Component
public class ProducerOne {

    @Autowired
    private DefaultMQProducer producer;

    public void syncSendMessage() {
        Message message = null;
        try {
            ConsumerOneMessageBO oneMessageBO = new ConsumerOneMessageBO(11, "张三");
            String msgJson = JSONObject.toJSONString(oneMessageBO);
            message = new Message(
                    "one-topic",
                    msgJson.getBytes(RemotingHelper.DEFAULT_CHARSET)
            );
            this.producer.send(message, new SendCallback() {
                @Override
                public void onSuccess(SendResult sendResult) {
                    System.out.println("发送成功:" + sendResult);
                }

                @Override
                public void onException(Throwable throwable) {
                    System.out.println("发送失败：" + throwable.getMessage());
                }
            });
        } catch (Exception e) {
            System.out.println("发送消息错误");
            e.printStackTrace();
        }
    }
}