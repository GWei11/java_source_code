package com.example.rocketmqdemo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @version 1.0
 * @className MQProperties.java
 * @description
 */
@ConfigurationProperties("spring.rocketmq")
@Data
public class MQProperties {

    public static final String PREFIX = "spring.rocketmq";
    private String namesrvAddr;
    private String producerGroupName;
    private Integer sendMsgTimeout = 3000;
    private Integer retryNum = 3;
    private boolean vipChannelEnabled = false;

}