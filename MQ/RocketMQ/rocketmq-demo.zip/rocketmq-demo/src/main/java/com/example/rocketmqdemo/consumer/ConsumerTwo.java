package com.example.rocketmqdemo.consumer;

import com.example.rocketmqdemo.anno.MQConsumer;
import org.springframework.stereotype.Component;

/**
 * @className ConsumerTwo.java
 * @description //TODO
 * @version 1.0
 */
@MQConsumer(consumerGroup = "consumer-two-group", topic = "two-topic")
@Component
public class ConsumerTwo {
}