package com.example.rocketmqdemo.controller;

import com.example.rocketmqdemo.producer.ProducerOne;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @version 1.0
 * @className ControllerDemo.java
 * @description //TODO
 */
@Controller
public class ControllerDemo {

    @Autowired
    private ProducerOne producer;

    @RequestMapping("/testone")
    @ResponseBody
    public String testOne () {
        producer.syncSendMessage();
        return "测试成功";
    }
}