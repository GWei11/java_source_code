package com.example.rocketmqdemo.consumer;

import com.example.rocketmqdemo.anno.MQConsumer;
import com.example.rocketmqdemo.bo.ConsumerOneMessageBO;
import com.example.rocketmqdemo.interace.AbstractMQPushConsumer;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @className ConsumerOne.java
 * @description //TODO
 * @version 1.0
 */
@MQConsumer(consumerGroup = "consumer-one-group", topic = "one-topic")
@Component
public class ConsumerOne extends AbstractMQPushConsumer<ConsumerOneMessageBO> {
    @Override
    public boolean process(ConsumerOneMessageBO var1, Map<String, Object> var2) {
        System.out.println("接受到消息");
        System.out.println(var1);
        Object test = var2.get("TEST");
        System.out.println(test);
        return true;
    }
}